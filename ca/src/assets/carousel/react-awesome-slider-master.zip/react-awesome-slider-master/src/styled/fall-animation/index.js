import Styles from './fall-animation.scss';

export default Styles;
