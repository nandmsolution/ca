import Styles from './cube-animation.scss';

export default Styles;
