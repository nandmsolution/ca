import Styles from './open-animation.scss';

export default Styles;
