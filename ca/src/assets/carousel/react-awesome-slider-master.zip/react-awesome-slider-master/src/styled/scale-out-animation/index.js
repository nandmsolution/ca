import Styles from './scale-out-animation.scss';

export default Styles;
