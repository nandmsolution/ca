import Styles from './fold-out-animation.scss';

export default Styles;
