import AwesomeSlider from './core';

export default AwesomeSlider;
