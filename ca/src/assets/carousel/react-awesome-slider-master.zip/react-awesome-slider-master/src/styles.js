import styles from './core/styles.scss';

export default styles;
